const db = require('../../config/database');

const getLossAllowanceReport = async (req, res) => {
    const { startDate, endDate, startRunKey, endRunKey } = req.query;
    let connection;

    // Validate required parameters
    if (!startDate || !endDate || !startRunKey || !endRunKey) {
        return res.status(400).json({
            success: false,
            error: 'Missing required parameters: startDate, endDate, startRunKey, and endRunKey are required'
        });
    }

    try {
        connection = await db.getConnection();
        
        // Get opening balances
        const openingBalanceQuery = `
            SELECT 
                frl.n_curr_ifrs_stage_skey as stage,
                SUM(frl.n_12m_ecl_ncy) as opening_balance
            FROM fct_reporting_lines frl
            WHERE frl.fic_mis_date = ? AND frl.n_run_key = ?
            GROUP BY frl.n_curr_ifrs_stage_skey
            ORDER BY frl.n_curr_ifrs_stage_skey;
        `;

        // Get new financial assets
        const newAssetsQuery = `
            SELECT 
                frl.n_curr_ifrs_stage_skey as stage,
                SUM(frl.n_12m_ecl_ncy) as new_assets
            FROM fct_reporting_lines frl
            LEFT JOIN fct_reporting_lines prev ON 
                frl.n_account_number = prev.n_account_number AND 
                prev.fic_mis_date = ? AND 
                prev.n_run_key = ?
            WHERE frl.fic_mis_date = ? AND frl.n_run_key = ?
                AND prev.n_account_number IS NULL
            GROUP BY frl.n_curr_ifrs_stage_skey
            ORDER BY frl.n_curr_ifrs_stage_skey;
        `;

        // Get stage transfers
        const stageTransfersQuery = `
            WITH current_stages AS (
                SELECT 
                    n_account_number,
                    n_curr_ifrs_stage_skey as current_stage,
                    n_12m_ecl_ncy as current_ecl
                FROM fct_reporting_lines
                WHERE fic_mis_date = ? AND n_run_key = ?
            ),
            previous_stages AS (
                SELECT 
                    n_account_number,
                    n_curr_ifrs_stage_skey as previous_stage,
                    n_12m_ecl_ncy as previous_ecl
                FROM fct_reporting_lines
                WHERE fic_mis_date = ? AND n_run_key = ?
            )
            SELECT 
                ps.previous_stage as from_stage,
                cs.current_stage as to_stage,
                SUM(cs.current_ecl) as transfer_amount
            FROM current_stages cs
            JOIN previous_stages ps ON cs.n_account_number = ps.n_account_number
            WHERE ps.previous_stage != cs.current_stage
            GROUP BY ps.previous_stage, cs.current_stage
            ORDER BY ps.previous_stage, cs.current_stage;
        `;

        // Get credit risk changes
        const creditRiskQuery = `
            WITH current_stages AS (
                SELECT 
                    n_account_number,
                    n_curr_ifrs_stage_skey as stage,
                    n_12m_ecl_ncy as current_ecl,
                    n_pd_percent as current_pd
                FROM fct_reporting_lines
                WHERE fic_mis_date = ? AND n_run_key = ?
            ),
            previous_stages AS (
                SELECT 
                    n_account_number,
                    n_curr_ifrs_stage_skey as stage,
                    n_12m_ecl_ncy as previous_ecl,
                    n_pd_percent as previous_pd
                FROM fct_reporting_lines
                WHERE fic_mis_date = ? AND n_run_key = ?
            )
            SELECT 
                cs.stage,
                SUM(CASE 
                    WHEN cs.current_pd > ps.previous_pd THEN cs.current_ecl - ps.previous_ecl
                    ELSE 0 
                END) as deterioration,
                SUM(CASE 
                    WHEN cs.current_pd < ps.previous_pd THEN cs.current_ecl - ps.previous_ecl
                    ELSE 0 
                END) as improvement
            FROM current_stages cs
            JOIN previous_stages ps ON cs.n_account_number = ps.n_account_number
            WHERE cs.stage = ps.stage
            GROUP BY cs.stage
            ORDER BY cs.stage;
        `;

        // Get derecognitions and write-offs
        const derecognitionsQuery = `
            SELECT 
                prev.n_curr_ifrs_stage_skey as stage,
                SUM(prev.n_12m_ecl_ncy) as derecognition_amount
            FROM fct_reporting_lines prev
            LEFT JOIN fct_reporting_lines curr ON 
                prev.n_account_number = curr.n_account_number AND 
                curr.fic_mis_date = ? AND 
                curr.n_run_key = ?
            WHERE prev.fic_mis_date = ? AND prev.n_run_key = ?
                AND curr.n_account_number IS NULL
            GROUP BY prev.n_curr_ifrs_stage_skey
            ORDER BY prev.n_curr_ifrs_stage_skey;
        `;

        // Get closing balances
        const closingBalanceQuery = `
            SELECT 
                frl.n_curr_ifrs_stage_skey as stage,
                SUM(frl.n_12m_ecl_ncy) as closing_balance
            FROM fct_reporting_lines frl
            WHERE frl.fic_mis_date = ? AND frl.n_run_key = ?
            GROUP BY frl.n_curr_ifrs_stage_skey
            ORDER BY frl.n_curr_ifrs_stage_skey;
        `;

        // Execute all queries
        const [
            openingBalances,
            newAssets,
            stageTransfers,
            creditRiskChanges,
            derecognitions,
            closingBalances
        ] = await Promise.all([
            connection.execute(openingBalanceQuery, [startDate, startRunKey]),
            connection.execute(newAssetsQuery, [startDate, startRunKey, endDate, endRunKey]),
            connection.execute(stageTransfersQuery, [endDate, endRunKey, startDate, startRunKey]),
            connection.execute(creditRiskQuery, [endDate, endRunKey, startDate, startRunKey]),
            connection.execute(derecognitionsQuery, [endDate, endRunKey, startDate, startRunKey]),
            connection.execute(closingBalanceQuery, [endDate, endRunKey])
        ]);

        // Process and format the data
        const report = {
            opening_balance: openingBalances[0],
            new_assets: newAssets[0],
            stage_transfers: stageTransfers[0],
            credit_risk_changes: creditRiskChanges[0],
            derecognitions: derecognitions[0],
            closing_balance: closingBalances[0]
        };

        res.json({ 
            success: true, 
            data: report,
            metadata: {
                startDate,
                endDate,
                startRunKey,
                endRunKey
            }
        });
    } catch (err) {
        console.error('Error generating loss allowance report:', err);
        res.status(500).json({ 
            success: false, 
            error: 'Failed to generate loss allowance report',
            details: err.message 
        });
    } finally {
        if (connection) connection.release();
    }
};

module.exports = {
    getLossAllowanceReport
};
