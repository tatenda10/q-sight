-- First, drop the existing unique constraint
ALTER TABLE ldn_customer_info DROP INDEX unique_party_id;

-- Then, add a composite unique constraint
ALTER TABLE ldn_customer_info ADD CONSTRAINT unique_party_mis_date UNIQUE (v_party_id, fic_mis_date);
